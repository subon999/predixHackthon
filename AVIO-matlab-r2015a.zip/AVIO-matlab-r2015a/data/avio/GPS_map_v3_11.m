function out = GPS_map_v3_11(speeds, stat_lat, stat_lon, core)

% Evaluation of Mission course from speed information
% and initial GPS coordinates
% versions history
% %
% % v1: first functioning version
% % v.1.5: extraction code added
% % v2: time stamp fixed, DirDis2GPS generalized by R
% % v3: extraction code external as main code, validation with new data
% % v3.4: Added Savitzky-Golay numerical filter of source data,
% % subplot and speed plot for debug and reports
% % v3.6: initial test of data cleaning function
% % v3.10 debugging/verification
% % v3.11 final (no modification)
% %
% CODE

speeds_m_sec = speeds*0.3048; % conversion of speeds matrix from ft/sec to m/sec
space=(speeds_m_sec*0.5); % calculate distance in singles directions in m for every sample [m/sec to m](0.5 = 2 samples/s)
space=space/1000; % conversion from m to km
M_Mov=zeros(length(space(:,1)),5); % Inizialization of results matrix
M_Mov(1,3)=stat_lat; % (Lat)
M_Mov(1,4)=stat_lon; % (Long)
for k=1:1:length(space(:,1))
M_Mov(k,1)=sqrt((space(k,1)^2)+(space(k,2)^2)); % compute the absolute distance for every sample 

%2
M_Mov(k,2)=rad2deg(atan2(speeds(k,2),speeds(k,1))); % compute the direction for every sample [deg]
end
altitude=cumsum(space(:,3)); % Altitude profile calculation [km]
for k=2:1:length(space(:,1)) %
[M_Mov(k,3),M_Mov(k,4)]=DirDis2GPS_v3_2(M_Mov(k,2),...
M_Mov(k,1),M_Mov(k-1,3),M_Mov(k-1,4),altitude(k)); % Calling GPS position estimation function ("help DirDis2GPS_v3_1" for details)
end
% writing kml file for google maps purposes
% define filename
prefix='course_';
ext='_valid.kml';
filename=strcat(prefix,core,ext);
% Export data to .kml file
% kmlwriteline(filename, M_Mov(:, 3), M_Mov(:, 4), 'Color', 'red', 'LineWidth', 5);
% Distance Verification
disp('----------------')
disp(core);
td_num=cumsum(M_Mov(:,1));
td_num=td_num(end);
td = sprintf('Flight Total distance = %d',td_num);
disp(td);
n=cumsum(space(:,1));
n=n(end);
e=cumsum(space(:,2));
e=e(end);
% computing space fro
d=sqrt((n^2)+(e^2));
fd = sprintf('Distance from data = %d',d);
disp(fd);
lat1=deg2rad(M_Mov(1,3));
lat2=deg2rad(M_Mov(end,3));
lon1=deg2rad(M_Mov(1,4));
lon2=deg2rad(M_Mov(end,4));
deltaLat=lat2-lat1;
deltaLon=lon2-lon1;
x=deltaLon*cos((lat1+lat2)/2);
y=deltaLat;
dkm=6378.137*sqrt(x*x + y*y); %Pythagoran distance
fc = sprintf('Distance from calculation = %d',dkm);
disp(fc);

%3
comp=abs(d-dkm);
dp = sprintf('The difference is <strong>%d</strong>',comp);
disp(dp);
err_perc=comp/td_num;
ep = sprintf('The error on total course is <strong>%d %%</strong>',err_perc);
disp(ep);
disp('----------------')

out = ['{"Flight Total distance" : ', num2str(td_num), ', "Distance from data" : ', num2str(d), ', "Distance from calculation" : ', num2str(dkm), ', "The difference" : ', num2str(comp), ', "The error on total course" : ', num2str(err_perc), ', "loc" :['];
for i = 1:length(M_Mov)
out = [out, strcat('{"long" : ', num2str(M_Mov(i, 3)), ', "latt" : ', num2str(M_Mov(i, 4)), '},')];
end
out = [out(1:end - 1), ']}'];
end