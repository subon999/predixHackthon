function out = extraction(fileName)

stat_lat = 44.9987003; % (Lat)
stat_lon = 7.4979972; % (Long)

A = csvread(fileName , 1, 0); %read csv
% Note for TechMahindra
% In our scenario, the “A�? object will be read from the DB table named avio_data on the Postgres dump – it represents the Matlab matrix containing the data coming from the csv.

speeds = A(:, 80:82); %only speed information: columns M51, M52, M59
prefix = 'speeds_';% define and compose name of the .mat file to save
core = 'avio_data';
ext = '_valid.mat';
save_filename = strcat(prefix, core, ext);
[speeds] = fun_filter(speeds); % Error correction function calling
out = GPS_map_v3_11(speeds, stat_lat, stat_lon, core); % GPS course estimation function calling
% save(save_filename,'speeds','M_Mov'); %saving .mat
% clear A speeds save_filename core M_Mov k % eliminate data to avoid error and discharge memory
% clear prefix ext d d1 d2 d3 list stat_lat list_dir stat_lon %eliminate data to discharge memory

end