/*
 * Copyright (c) 2016 General Electric Company. All rights reserved.
 *
 * The copyright to the computer software herein is the property of
 * General Electric Company. The software may be used and/or copied only
 * with the written permission of General Electric Company or in accordance
 * with the terms and conditions stipulated in the agreement/contract
 * under which the software has been supplied.
 */
 
package com.ge.predix.insight.analytic.demo.matlab;


import com.mathworks.toolbox.javabuilder.MWException;


public class MatlabCall
{

	public static void main(String[] args)
	{
		//System.load("C:/Program Files (x86)/MATLAB/MATLAB Runtime/v85/runtime/win32/mclmcrrt8_5.dll");
		//System.out.println(System.getProperty("java.library.path"));
		//System.loadLibrary('C:/Program Files (x86)/MATLAB/MATLAB Runtime/v85/runtime/win32');
		AvioReg avio =new AvioReg();
		try
		{
			System.out.println("in task");
			//Object[] rslt = matlab.LocomotiveRegression(1, args[0]);
			
			
		}
		finally
		{
			System.out.println("in finally");
			System.out.println(avio.AvioRegression(args[0]));
		}
	}

}